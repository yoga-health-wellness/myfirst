

<nav class="navbar navbar-expand-md" style="    background: #efe8de00 url(images/header-bg.png) no-repeat 203px 30px;
    margin: -14px auto;">
	<div class="container">
		<a class="navbar-brand" href="index.php"><img src="images/yoga-logo.png" alt="Yoga Health & Wellness">
		</a>
			<div class="row no-gutters align-items-center header">
			<div class="col-md-12 col-7">
				<div class="head-call">
					<div class="call-icon">
						<i class="fas fa-phone-alt"></i>
						<p class=" d-inline-block">9021479621</p>
					</div> 
						<div class="call-icon">
						<a href="javascript:void(0);"><i class="fab fa-facebook-square"></i></a>
					</div>
						<div class="call-icon">
						<a href="javascript:void(0);"><i class="fab fa-twitter-square"></i></a>
					</div>
						<div class="call-icon">
						<a href="javascript:void(0);"><i class="fa fa-youtube-square"></i></a>
					</div>
				</div>
			</div>
			
		</div>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="fas fa-bars"></span>
	  </button>

	  <div class="collapse navbar-collapse" id="navbarSupportedContent">
	    <ul class="navbar-nav ml-auto">
	      <li class="nav-item active">
	        <a class="nav-link" href="index.php">Home<span class="sr-only">(current)</span></a>
	      </li>
	      <li class="nav-item">
	        <a class="nav-link" href="about.php">About Trainer</a>
	      </li> 
	     
	      <li class="nav-item">
	        <a class="nav-link" href="services.php">Courses</a>
	      </li>
	  <!--     <li class="nav-item">
	        <a class="nav-link" href="index.php">Treatments</a>
	      </li> -->
	      <li class="nav-item">
	        <a class="nav-link" href="testimonials.php">Testimonials</a>
	      </li>
	       <li class="nav-item">
	        <a class="nav-link" href="contact.php">Gallery</a>
	      </li>
	       <li class="nav-item">
	        <a class="nav-link" href="contact.php">Contact</a>
	      </li>
	        <li class="nav-item">
	        <a class="nav-link" href="covid.php">COVID-19</a>
	      </li>
	    </ul>
	  </div>
	</div>
</nav>