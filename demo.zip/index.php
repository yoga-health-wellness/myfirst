<?php $title="Yoga Health & Wellness"?>
<?php include'includes/head.php';?>
<?php include'includes/menu.php';?>
<div id="demo" class="carousel slide" data-ride="carousel">

  <!-- Indicators -->
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  
  <!-- The slideshow -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/yoga-banner-2.jpg" alt="Yoga Health & Wellness banner1" >
       <div class="container banner-tittle text-left">
        <div class="row">
             
            <div class="col-md-6 col-6">
                <h1 class="text-uppercase pb-2 ">WE ARE VERY CAREFUL  
</h1> 
<p class=" f600">WE TAKE CARE YOUR FITNESS</p>
                <!--<div class="pt-5 d-none d-sm-block">-->
                <!--      <a href="fracture-and-trauma-care.php" class="btn button">KNOW MORE</a>-->
                <!--</div>-->
              
            </div>
             <div class="col-md-6"></div>
          </div>    
        </div>
    </div>
  
  </div>
  
  <!-- Left and right controls -->
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>


<section class="about-area pb-100">
<div class="container">
<div class="row align-items-center">
<div class="col-lg-6">
<div class="about-main-image">
<img src="images/yoga-trainer.jpg" alt="image">
 <div class="about-shape">

<div class="shape-5">
<img src="images/shape-5.png" alt="image">
</div>
</div>
</div>
</div>
<div class="col-lg-6">
<div class="about-main-content">
<h1 class="heading-top1 ">About Trainer</h1>

<p>Lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
<p>Lorem ipsum dolor sit amet consetetur sadipsy ci ngelapit elitr sed diam nonumy eirmod temp por invidunt ut labore et dolore magna.</p>
<div class="row">
<div class="col-lg-6 col-sm-6">
<div class="about-information">
<i class="fa fa-trophy"></i>
<h5>5+ Years</h5>
<span>Experience</span>
</div>
</div>
<!-- <div class="col-lg-6 col-sm-6">
<div class="about-information">
<i class="flaticon-customer"></i>
<h5>1K+ Happy</h5>
<span>Clients</span>
</div>
</div> -->
</div>

</div>
</div>
</div>
</div>
<div class="about-main-shape">
<img src="images/line-shape.png" alt="image">
</div>
</section>


<footer class="bg_img"  id="contact">
       	<div class="footer-top">
  			<div class="container">
  				<div class="row">
  				
  						<div class="col-lg-4 col-sm-6 col-xs-12">
  					 <div class="footer-item">
               <h4 class="title text-white">About Us </h4>
              <p class="text-white">It’s time to roll out your yoga mat and discover the combination of physical and mental exercises…
             </div>
  					</div>
  				
  				<div class="col-lg-4 col-sm-6 col-xs-12">
  						  <div class="footer-item">
                <h4 class="title text-white">Contact Us </h4>
                <ul class="twitter-post">
                  <li>
                    <div class="icon"><i class="fa fa-home" aria-hidden="true"></i></div>
                    <div class="content">
                      <p class="text-white">Yoga Health & Wellness-<br>
                      
                      </p>
                    
                    </div>
                  </li>
                  <li>
                    <div class="icon"><i class="fa fa-phone" aria-hidden="true"></i></div>
                    <div class="content">
                      <p class="text-white">9021479621</p>
                    
                    </div>
                  </li>
                  <li>
                    <div class="icon"><i class="fa fa-envelope" aria-hidden="true"></i></div>
                    <div class="content">
                      <p class="text-white">marutiwaghmare8@gmail.com</p>
                      
                    </div>
                  </li>
                </ul>
              </div>
  				</div>
  					<div class="col-lg-4 col-sm-6 col-xs-12">
  						<div class="footer-item">
  						   <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fcrp1216%2F&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=505429700341863" width="100%" height="320" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
  						</div>
  				</div>
  				</div><!-- row -->
  			</div><!-- container -->
  		</div><!-- footer top -->
  		<div class="footer-bottom">
  			<div class="container">
  				<div class="row">
	  				<div class="col-lg-6 col-xs-12">
	  					<p> Copyright &copy; 2021 All Rights Reserved, By Yoga Health & Wellness</p>
	  				</div>
	  				<div class="col-lg-6 col-xs-12">
	  					<ul class="social-default">
			  				<li><a href="" target="_blank">
			  				    <i class="fa fa-facebook" aria-hidden="true"></i></a></li>
			  				<li><a href="" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
			  			    <li><a href="" target="_blank"><i class="fa fa-youtube-square" aria-hidden="true" ></i></a></li>
			  			</ul>
	  				</div>
	  			</div><!-- row -->
  			</div><!-- container -->
  		</div><!-- footer bottom -->
    </footer>
<!--<div class="navbar-fixed-bottom d-lg-none d-xl-none d-md-none d-sm-none col-xs-12 " style="width:100%;text-align: center;position: fixed;right: 0;bottom: 0;left: 0;padding: 4px;background-color:lightgray;text-align: center;z-index:29">-->
<!--<div class="d-lg-none d-xl-none d-md-none d-sm-none col-xs-12" style="background-color:#f9765c;margin-top: 6px;padding:8px;  ">-->
<!--<a href="tel:02225920606" style="color:white;">-->
<!--<img src="images/call.png" style="    width: 32px;" alt="Call"> Call For Appointment</a>-->
<!--</div>-->
<!--</div>-->
 <script src="js/jquery-3.3.1.slim.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/script.js"></script>
  
</body>
</html>
