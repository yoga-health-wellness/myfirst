<?php $title="Yoga Health & Wellness"?>
<?php include'includes/head.php';?>
<?php include'includes/menu.php';?>

<div class="jumbotron  banner-section text-center py-3 mt-4 pb-0">

<div class="container">
  

  <div class="row no-gutters align-items-center justify-content-center">
            <div class="col-12">
              <div class="content-part text-center">
                <div class="section-header">
                                    <h1 class="text-info">{{title}}</h1>
                                    <h3>All Live Updates</h3>
                 
                </div>
              </div>
            </div>
            <div class="col-12">
              <div class="section-wrapper">
                <div class="banner-thumb">
                  <img src="images/011.png" alt="lab-banner">
                </div>
              </div>
            </div>
          </div>
</div>

<div class="container p-0">
    <div class="row pb-5">
        <div class="col-md-4 p-0">
            <div class="card bg-warning">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                             <h2 class="pb-2  text-white">Confirmed</h2>
                    <h3 class=" text-white">{{all_data.confirmed.value}}</h3>
                        </div>
                         <div class="col-md-4">
                            <img src="images/01.png">
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>
        
        
         <div class="col-md-4 p-0">
            <div class="card bg-success">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                              <h2 class="pb-2  text-white">Recovered</h2>
                      <h3 class=" text-white">{{all_data.recovered.value}}</h3>
                        </div>
                         <div class="col-md-4">
                            <img src="images/02.png">
                        </div>
                    </div>
                   
                </div>
               
            </div>
        </div>
        
         <div class="col-md-4 p-0">
            <div class="card bg-danger">
                 <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                              <h2 class="pb-2 text-white">Deaths</h2>
                      <h3 class=" text-white">{{all_data.deaths.value}}</h3>
                        </div>
                         <div class="col-md-4">
                            <img src="images/03.png">
                        </div>
                    </div>
                   
                </div>
              
            </div>
        </div>
    </div>
     <div class="row">
         <input type="text" class="form-control" placeholder="Enter Country name 
   " ng-model="c" ng-change="get_c_data()"> 
   
     </div>
  
    <div class="container" ng-if="c_data">
   
    
    <h1 class="text-uppercase text-center text-success pb-3 pt-3">{{c }} Status</h1>
    
      <div class="row pb-4">
        <div class="col-md-4">
            <div class="card bg-warning">
                 <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                              <h2 class="pb-2  text-white">Confirmed</h2>
                    <h3 class=" text-white">{{c_data.confirmed.value}}</h3>
                        </div>
                         <div class="col-md-4">
                            <img src="images/01.png">
                        </div>
                    </div>
                   
                </div>
                
            </div>
        </div>
        
         <div class="col-md-4">
            <div class="card bg-danger">
                 <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <h2 class="pb-2  text-white">Recovered</h2>
                      <h3 class=" text-white">{{c_data.recovered.value}}</h3>
                        </div>
                         <div class="col-md-4">
                            <img src="images/02.png">
                        </div>
                    </div>
                   
                </div>
               
            </div>
        </div>
        
         <div class="col-md-4">
            <div class="card bg-success">
                 <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                              <h2 class="pb-2 text-white">Deaths</h2>
                      <h3 class=" text-white">{{c_data.deaths.value}}</h3>
                        </div>
                         <div class="col-md-4">
                            <img src="images/01.png">
                        </div>
                    </div>
                   
                </div>
            </div>
        </div>
        
    </div>
        
    </div>
    </div>
</div>



<footer class="bg_img"  id="contact">
        <div class="footer-top">
        <div class="container">
          <div class="row">
          
              <div class="col-lg-4 col-sm-6 col-xs-12">
             <div class="footer-item">
               <h4 class="title text-white">About Us </h4>
              <p class="text-white">It’s time to roll out your yoga mat and discover the combination of physical and mental exercises…
             </div>
            </div>
          
          <div class="col-lg-4 col-sm-6 col-xs-12">
                <div class="footer-item">
                <h4 class="title text-white">Contact Us </h4>
                <ul class="twitter-post">
                  <li>
                    <div class="icon"><i class="fa fa-home" aria-hidden="true"></i></div>
                    <div class="content">
                      <p class="text-white">Yoga Health & Wellness-<br>
                      
                      </p>
                    
                    </div>
                  </li>
                  <li>
                    <div class="icon"><i class="fa fa-phone" aria-hidden="true"></i></div>
                    <div class="content">
                      <p class="text-white">9021479621</p>
                    
                    </div>
                  </li>
                  <li>
                    <div class="icon"><i class="fa fa-envelope" aria-hidden="true"></i></div>
                    <div class="content">
                      <p class="text-white">marutiwaghmare8@gmail.com</p>
                      
                    </div>
                  </li>
                </ul>
              </div>
          </div>
            <div class="col-lg-4 col-sm-6 col-xs-12">
              <div class="footer-item">
                 <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2Fcrp1216%2F&tabs=timeline&width=340&height=500&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=505429700341863" width="100%" height="320" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
              </div>
          </div>
          </div><!-- row -->
        </div><!-- container -->
      </div><!-- footer top -->
      <div class="footer-bottom">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 col-xs-12">
              <p> Copyright &copy; 2021 All Rights Reserved, By Yoga Health & Wellness</p>
            </div>
            <div class="col-lg-6 col-xs-12">
              <ul class="social-default">
                <li><a href="" target="_blank">
                    <i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                <li><a href="" target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                  <li><a href="" target="_blank"><i class="fa fa-youtube-square" aria-hidden="true" ></i></a></li>
              </ul>
            </div>
          </div><!-- row -->
        </div><!-- container -->
      </div><!-- footer bottom -->
    </footer>
<!--<div class="navbar-fixed-bottom d-lg-none d-xl-none d-md-none d-sm-none col-xs-12 " style="width:100%;text-align: center;position: fixed;right: 0;bottom: 0;left: 0;padding: 4px;background-color:lightgray;text-align: center;z-index:29">-->
<!--<div class="d-lg-none d-xl-none d-md-none d-sm-none col-xs-12" style="background-color:#f9765c;margin-top: 6px;padding:8px;  ">-->
<!--<a href="tel:02225920606" style="color:white;">-->
<!--<img src="images/call.png" style="    width: 32px;" alt="Call"> Call For Appointment</a>-->
<!--</div>-->
<!--</div>-->
 <script src="js/jquery-3.3.1.slim.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/script.js"></script>
  
</body>
</html>